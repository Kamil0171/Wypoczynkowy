from django.apps import AppConfig


class AplikacjaWebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Aplikacja_web'
