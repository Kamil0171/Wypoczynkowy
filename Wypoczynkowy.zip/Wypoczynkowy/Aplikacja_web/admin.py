from django.contrib import admin
from .models import Kontakt
from .models import Wydarzenie

from .models import Ogloszenie
from .models import Impreza


# Register your models here.

admin.site.register(Kontakt)


admin.site.register(Wydarzenie)

admin.site.register(Ogloszenie)

admin.site.register(Impreza)

