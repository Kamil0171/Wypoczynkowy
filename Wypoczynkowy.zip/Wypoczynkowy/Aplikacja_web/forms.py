from django import forms
from .models import Wydarzenie
from .models import Ogloszenie
from .models import Zdjecie
from django_recaptcha.fields import ReCaptchaField
from .models import Opinia

class ContactForm(forms.Form):
    imie_nazwisko = forms.CharField(
        widget=forms.TextInput(attrs={
            "placeholder": "Imię i nazwisko",
            "class": "form-control"
        })
    )
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            "placeholder": "Twój e-mail",
            "class": "form-control"
        })
    )
    tresc = forms.CharField(
        widget=forms.Textarea(attrs={
            "placeholder": "Twoja wiadomość",
            "class": "form-control",
            "rows": 5
        })
    )

    tresc = forms.CharField(
        widget=forms.Textarea(attrs={
            "placeholder": "Twoja wiadomość",
            "class": "form-control",
            "rows": 5
        })
    )
    captcha = ReCaptchaField()



class WydarzenieForm(forms.ModelForm):
    data_rozpoczecia = forms.DateTimeField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'id': 'datepicker-start',
            'placeholder': 'DD.MM.YYYY HH:MM'
        }),
        input_formats=['%d.%m.%Y %H:%M']
    )
    data_zakonczenia = forms.DateTimeField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'id': 'datepicker-end',
            'placeholder': 'DD.MM.YYYY HH:MM'
        }),
        input_formats=['%d.%m.%Y %H:%M']
    )

    captcha = ReCaptchaField()


    class Meta:
        model = Wydarzenie
        fields = ['tytul', 'opis', 'data_rozpoczecia', 'data_zakonczenia', 'lokalizacja', 'zdjecie', 'kategoria']


class OgloszenieForm(forms.ModelForm):
    class Meta:
        model = Ogloszenie
        fields = [
            'tytul', 'opis', 'kategoria', 'lokalizacja', 'cena_za_dobe',
            'pokoje', 'max_osob', 'zdjecie_glowne', 'data_dostepnosci_od',
            'data_dostepnosci_do'
        ]
        widgets = {
            'tytul': forms.TextInput(attrs={'class': 'form-control'}),
            'opis': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'kategoria': forms.Select(attrs={'class': 'form-select'}),
            'lokalizacja': forms.TextInput(attrs={'class': 'form-control'}),
            'cena_za_dobe': forms.NumberInput(attrs={'class': 'form-control'}),
            'pokoje': forms.NumberInput(attrs={'class': 'form-control'}),
            'max_osob': forms.NumberInput(attrs={'class': 'form-control'}),
            'zdjecie_glowne': forms.FileInput(attrs={'class': 'form-control'}),
            'data_dostepnosci_od': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'data_dostepnosci_do': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
        }


class ZdjecieForm(forms.ModelForm):
    class Meta:
        model = Zdjecie
        fields = ['zdjecie']


class OpiniaForm(forms.ModelForm):
    class Meta:
        model = Opinia
        fields = ['ocena', 'tresc']
        widgets = {
            'ocena': forms.Select(attrs={'class': 'form-select'}),
            'tresc': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Napisz swoją opinię...'}),
        }

