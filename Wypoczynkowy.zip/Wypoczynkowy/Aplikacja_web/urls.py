from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('logout/', views.logout_view, name='logout'),
    path('formularz/', views.formularz_view, name='formularz'),
    path('kontakt/', views.contact_view, name='kontakt'),
    path('success/', views.formularz_view, name='success'),
    path('add-events/', views.dodaj_wydarzenie, name='dodaj_wydarzenie'),
    path('oserwisie/', views.oserwisie_view, name='oserwisie'),
    path('cennik/', views.cennik_view, name='cennik'),
    path('ogloszenia/', views.ogloszenia, name='ogloszenia'),
    path('ogloszenie/<int:id>/', views.ogloszenie_detail, name='ogloszenie_detail'),
    path('dodaj/', views.dodaj_ogloszenie, name='dodaj_ogloszenie'),
    path('imprezy/', views.imprezy, name='imprezy'),
    path('impreza/<int:id>/', views.impreza_detail, name='impreza_detail'),
    path('archiwum-ogloszen/', views.archiwum_ogloszen, name='archiwum_ogloszen'),
    path('wydarzenia/', views.wydarzenia, name='wydarzenia'),
    path('wydarzenie/<int:id>/', views.wydarzenie_detail, name='wydarzenie_detail'),
    path('infoipomoc/', views.infoipomoc_view, name='infoipomoc'),
]
