# Dodaj na końcu pliku, przed ostatnim if __name__ == '__main__':

STATIC_ROOT = '/app/staticfiles' 