from django.db import models
from django.contrib.auth.models import User
from django.conf import settings


class Kontakt(models.Model):
    imie_nazwisko = models.CharField(max_length=100)
    email = models.EmailField()
    tresc = models.TextField()


class Wydarzenie(models.Model):
    tytul = models.CharField(max_length=200)
    opis = models.TextField()
    data_rozpoczecia = models.DateTimeField()
    data_zakonczenia = models.DateTimeField()
    lokalizacja = models.CharField(max_length=255)
    zdjecie = models.ImageField(upload_to='wydarzenia/', blank=True, null=True)
    kategoria = models.CharField(max_length=100)
    autor = models.ForeignKey(User, on_delete=models.CASCADE)
    data_dodania = models.DateTimeField(auto_now_add=True)
    jest_aktywne = models.BooleanField(default=True)

    def __str__(self):
        return self.tytul

class Ogloszenie(models.Model):
    KATEGORIA_CHOICES = [
        ('apartament', 'Apartament'),
        ('dom', 'Dom'),
        ('pokoj', 'Pokój'),
        ('domek', 'Domek letniskowy'),
    ]

    tytul = models.CharField(max_length=200, null=True, blank=True)
    opis = models.TextField(null=True, blank=True)
    kategoria = models.CharField(max_length=20, choices=KATEGORIA_CHOICES, null=True, blank=True)
    lokalizacja = models.CharField(max_length=100, null=True, blank=True)
    cena_za_dobe = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    pokoje = models.IntegerField(null=True, blank=True)
    max_osob = models.IntegerField(null=True, blank=True)
    zdjecie_glowne = models.ImageField(upload_to='ogloszenia/', null=True, blank=True)
    data_dodania = models.DateTimeField(auto_now_add=True)
    data_aktualizacji = models.DateTimeField(auto_now=True)
    data_dostepnosci_od = models.DateField(null=True, blank=True)
    data_dostepnosci_do = models.DateField(null=True, blank=True)
    wlasciciel = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    jest_aktywne = models.BooleanField(default=True)
    internet = models.BooleanField(default=False, verbose_name="Internet")
    basen = models.BooleanField(default=False, verbose_name="Basen")
    parking = models.BooleanField(default=False, verbose_name="Parking")
    klimatyzacja = models.BooleanField(default=False, verbose_name="Klimatyzacja")
    zwierzeta_dozwolone = models.BooleanField(default=False, verbose_name="Zwierzęta dozwolone")
    balkon = models.BooleanField(default=False, verbose_name="Balkon")
    tv = models.BooleanField(default=False, verbose_name="Telewizor")
    kuchnia = models.BooleanField(default=False, verbose_name="Kuchnia")

    class Meta:
        ordering = ['-data_dodania']
        verbose_name = 'Ogłoszenie'
        verbose_name_plural = 'Ogłoszenia'

    def __str__(self):
        return self.tytul

class Zdjecie(models.Model):
    ogloszenie = models.ForeignKey(Ogloszenie, related_name='zdjecia', on_delete=models.CASCADE)
    zdjecie = models.ImageField(upload_to='ogloszenia/')
    data_dodania = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['data_dodania']
        verbose_name = 'Zdjęcie'
        verbose_name_plural = 'Zdjęcia'

    def __str__(self):
        return f'Zdjęcie do {self.ogloszenie.tytul}'

class Impreza(models.Model):
    nazwa = models.CharField(max_length=255)
    data = models.DateField()
    miejsce = models.CharField(max_length=255)
    opis = models.TextField()
    zdjecie = models.ImageField(upload_to='imprezy/', null=True, blank=True)

    def __str__(self):
        return self.nazwa

class Opinia(models.Model):
    ogloszenie = models.ForeignKey('Ogloszenie', on_delete=models.CASCADE, related_name='opinie')
    autor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    ocena = models.PositiveSmallIntegerField(choices=[(i, str(i)) for i in range(1, 6)])
    tresc = models.TextField(max_length=1000)
    data_dodania = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('ogloszenie', 'autor')
        ordering = ['-data_dodania']

    def __str__(self):
        return f"Opinia {self.ocena}★ przez {self.autor} dla {self.ogloszenie}"
