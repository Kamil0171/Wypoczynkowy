from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import EmailMessage
from django.conf import settings
from .models import Ogloszenie, Opinia
from .forms import OgloszenieForm, OpiniaForm
from .models import Impreza
from django.utils import timezone
from django.core.paginator import Paginator
import requests
from django.db.models import Q, Avg

from .forms import ContactForm, WydarzenieForm
from .models import Wydarzenie

def home(request):
    # Pobierz najnowsze 6 aktywnych ogłoszeń
    najnowsze_ogloszenia = Ogloszenie.objects.filter(
        jest_aktywne=True,
        data_dostepnosci_do__gte=timezone.now().date()
    ).order_by('-data_dodania')[:6]
    
    # Pobierz najbliższe wydarzenia
    wydarzenia = Wydarzenie.objects.filter(
        data_rozpoczecia__gte=timezone.now(),
        jest_aktywne=True
    ).order_by('data_rozpoczecia')[:3]
    
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'home.html', {
        'najnowsze_ogloszenia': najnowsze_ogloszenia,
        'wydarzenia': wydarzenia,
        'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia,
        'star_range': range(1, 6),
    })

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            next_url = request.GET.get('next')
            if next_url:
                return redirect(next_url)
            return redirect('dashboard')
        else:
            messages.error(request, 'Nieprawidłowa nazwa użytkownika lub hasło.')
    return render(request, 'login.html')

def register_view(request):
    if request.method == 'POST':
        recaptcha_response = request.POST.get('g-recaptcha-response')
        data = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        r = requests.post('https://www.google.com/recaptcha/api/siteverify', data=data)
        result = r.json()

        if not result.get('success'):
            messages.error(request, 'Błąd weryfikacji reCAPTCHA.')
            return redirect('home')
        username = request.POST.get('username', '').strip()
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '').strip()
        password2 = request.POST.get('password2', '').strip()

        if password != password2:
            messages.error(request, 'Hasła się nie zgadzają.')
            return redirect('home')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Nazwa użytkownika jest już zajęta.')
            return redirect('home')

        user = User.objects.create_user(username=username, email=email, password=password)
        login(request, user)
        return redirect('home')

    return redirect('home')

@login_required
def dashboard_view(request):
    # Get user's announcements
    user_ogloszenia = Ogloszenie.objects.filter(wlasciciel=request.user).order_by('-data_dodania')
    
    # Get user's events
    user_wydarzenia = Wydarzenie.objects.filter(autor=request.user).order_by('-data_dodania')
    
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    context = {
        'title': 'Panel użytkownika',
        'user_ogloszenia': user_ogloszenia,
        'user_wydarzenia': user_wydarzenia,
        'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia,
        'star_range': range(1, 6),
    }
    return render(request, 'dashboard.html', context)

def logout_view(request):
    logout(request)
    return redirect('home')

def formularz_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            subject = 'Wiadomość kontaktowa ze strony'
            message = (
                f"Imię i nazwisko: {data['imie_nazwisko']}\n"
                f"Email: {data['email']}\n\n"
                f"Treść wiadomości:\n{data['tresc']}"
            )
            email = EmailMessage(
                subject=subject,
                body=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[settings.CONTACT_EMAIL],
                headers={'Reply-To': data['email']}
            )
            email.send()
            najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
            return render(request, 'success.html', {'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})
    else:
        form = ContactForm()
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'formularz.html', {'form': form, 'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def contact_view(request):
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'contact.html', {'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def oserwisie_view(request):
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'oserwisie.html', {'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def cennik_view(request):
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'cennik.html', {'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def infoipomoc_view(request):
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'infoipomoc.html', {'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def imprezy_view(request):
    return render(request, 'imprezy.html')

@login_required
def dodaj_wydarzenie(request):
    if request.method == 'POST':
        form = WydarzenieForm(request.POST, request.FILES)
        if form.is_valid():
            wydarzenie = form.save(commit=False)
            wydarzenie.autor = request.user
            wydarzenie.save()
            messages.success(request, "Wydarzenie zostało dodane pomyślnie.")
            return redirect('dashboard')
    else:
        form = WydarzenieForm()
    return render(request, 'dodaj_wydarzenie.html', {'form': form})

@login_required
def edytuj_wydarzenie(request, pk):
    wydarzenie = get_object_or_404(Wydarzenie, pk=pk, autor=request.user)
    form = WydarzenieForm(request.POST or None, request.FILES or None, instance=wydarzenie)
    if form.is_valid():
        form.save()
        messages.success(request, "Wydarzenie zostało zaktualizowane.")
        return redirect('dashboard')
    return render(request, 'dodaj_wydarzenie.html', {'form': form})

def get_najlepiej_oceniane_ogloszenia():
    return (
        Ogloszenie.objects.annotate(srednia_ocena=Avg('opinie__ocena'))
        .filter(srednia_ocena__isnull=False)
        .order_by('-srednia_ocena')[:3]
    )

def ogloszenia(request):
    # Pobierz wszystkie ogłoszenia
    ogloszenia_list = Ogloszenie.objects.all()
    
    # Pobierz unikalne lokalizacje
    lokalizacje = Ogloszenie.objects.values_list('lokalizacja', flat=True).distinct()
    
    # Pobierz kategorie
    kategorie = Ogloszenie.KATEGORIA_CHOICES
    
    # Inicjalizuj słownik filtrów
    current_filters = {}
    
    # Filtrowanie po kategorii
    kategoria = request.GET.get('kategoria')
    if kategoria:
        ogloszenia_list = ogloszenia_list.filter(kategoria=kategoria)
        current_filters['kategoria'] = kategoria
    
    # Filtrowanie po lokalizacji
    lokalizacja = request.GET.get('lokalizacja')
    if lokalizacja:
        ogloszenia_list = ogloszenia_list.filter(lokalizacja=lokalizacja)
        current_filters['lokalizacja'] = lokalizacja
    
    # Filtrowanie po cenie
    min_cena = request.GET.get('min_cena')
    max_cena = request.GET.get('max_cena')
    if min_cena:
        ogloszenia_list = ogloszenia_list.filter(cena_za_dobe__gte=min_cena)
        current_filters['min_cena'] = min_cena
    if max_cena:
        ogloszenia_list = ogloszenia_list.filter(cena_za_dobe__lte=max_cena)
        current_filters['max_cena'] = max_cena
    
    # Filtrowanie po dostępności
    data_od = request.GET.get('data_od')
    data_do = request.GET.get('data_do')
    if data_od:
        ogloszenia_list = ogloszenia_list.filter(data_dostepnosci_od__lte=data_od)
        current_filters['data_od'] = data_od
    if data_do:
        ogloszenia_list = ogloszenia_list.filter(data_dostepnosci_do__gte=data_do)
        current_filters['data_do'] = data_do
    
    # Sortowanie
    sort = request.GET.get('sort', '-data_dodania')
    if sort:
        ogloszenia_list = ogloszenia_list.order_by(sort)
        current_filters['sort'] = sort
    
    # Paginacja
    paginator = Paginator(ogloszenia_list, 9)  # 9 ogłoszeń na stronę
    page = request.GET.get('page')
    ogloszenia = paginator.get_page(page)
    
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    context = {
        'ogloszenia': ogloszenia,
        'lokalizacje': lokalizacje,
        'kategorie': kategorie,
        'current_filters': current_filters,
        'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia,
        'star_range': range(1, 6),
    }
    
    return render(request, 'ogloszenia.html', context)

def ogloszenie_detail(request, id):
    ogloszenie = get_object_or_404(Ogloszenie, id=id)
    opinie = ogloszenie.opinie.select_related('autor').all()
    srednia_ocena = opinie.aggregate(Avg('ocena'))['ocena__avg']
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    nowa_opinia = None
    if request.user.is_authenticated:
        if request.method == 'POST':
            form = OpiniaForm(request.POST)
            if form.is_valid():
                opinia = form.save(commit=False)
                opinia.ogloszenie = ogloszenie
                opinia.autor = request.user
                opinia.save()
                nowa_opinia = opinia
                form = OpiniaForm()  # reset form po dodaniu
            else:
                form = OpiniaForm()
        else:
            form = OpiniaForm()
    else:
        form = None
    return render(request, 'ogloszenie_detail.html', {
        'ogloszenie': ogloszenie,
        'opinie': opinie,
        'srednia_ocena': srednia_ocena,
        'form': form,
        'nowa_opinia': nowa_opinia,
        'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia,
        'star_range': range(1, 6),
    })

def dodaj_ogloszenie(request):
    if request.method == 'POST':
        form = OgloszenieForm(request.POST, request.FILES)
        if form.is_valid():
            ogloszenie = form.save(commit=False)
            ogloszenie.wlasciciel = request.user
            ogloszenie.save()
            messages.success(request, "Ogłoszenie zostało dodane pomyślnie.")
            return redirect('dashboard')
    else:
        form = OgloszenieForm()

    return render(request, 'dodaj_ogloszenie.html', {'form': form})

def imprezy(request):
    imprezy = Impreza.objects.all()
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'imprezy.html', {'imprezy': imprezy, 'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def impreza_detail(request, id):
    impreza = get_object_or_404(Impreza, id=id)
    podobne_imprezy = Impreza.objects.exclude(id=id).order_by('?')[:3]
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'impreza_detail.html', {
        'impreza': impreza,
        'podobne_imprezy': podobne_imprezy,
        'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia,
        'star_range': range(1, 6),
    })

def wydarzenia(request):
    wydarzenia = Wydarzenie.objects.filter(
        data_zakonczenia__gte=timezone.now(),
        jest_aktywne=True
    ).order_by('data_rozpoczecia')
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'wydarzenia.html', {'wydarzenia': wydarzenia, 'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def archiwum_ogloszen(request):
    ogloszenia = Ogloszenie.objects.filter(
        data_dostepnosci_do__lt=timezone.now().date()
    ).order_by('-data_dodania')
    najlepiej_oceniane_ogloszenia = get_najlepiej_oceniane_ogloszenia()
    return render(request, 'archiwum_ogloszen.html', {'ogloszenia': ogloszenia, 'najlepiej_oceniane_ogloszenia': najlepiej_oceniane_ogloszenia, 'star_range': range(1, 6)})

def wydarzenie_detail(request, id):
    wydarzenie = get_object_or_404(Wydarzenie, id=id)
    return render(request, 'wydarzenie_detail.html', {'wydarzenie': wydarzenie})

