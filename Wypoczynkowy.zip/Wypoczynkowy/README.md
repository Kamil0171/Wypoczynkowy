# Wypoczynkowy
# Wypoczynkowy2# >> README.md
git commit -am zmiana readme
pit push
git push
echo # Wypoczynkowy2#
