from django import forms
from .models import Ogloszenie

class OgloszenieForm(forms.ModelForm):
    class Meta:
        model = Ogloszenie
        fields = ['tytul', 'tresc', 'cena', 'lokalizacja', 'zdjecie', 'basen', 'wifi', 'klimatyzacja', 'parking', 'sauna', 'tv', 'grill', 'plac_zabaw', 'zwierzeta_dozwolone']
        widgets = {
            'tytul': forms.TextInput(attrs={'class': 'form-control'}),
            'tresc': forms.Textarea(attrs={'class': 'form-control'}),
            'cena': forms.NumberInput(attrs={'class': 'form-control'}),
            'lokalizacja': forms.TextInput(attrs={'class': 'form-control'}),
            'zdjecie': forms.FileInput(attrs={'class': 'form-control'}),
            'basen': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'wifi': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'klimatyzacja': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'parking': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'sauna': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'tv': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'grill': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'plac_zabaw': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'zwierzeta_dozwolone': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        } 