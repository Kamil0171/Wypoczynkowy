from django.db import models
from django.contrib.auth.models import User

class Ogloszenie(models.Model):
    tytul = models.CharField(max_length=200)
    tresc = models.TextField()
    data_dodania = models.DateTimeField(auto_now_add=True)
    autor = models.ForeignKey(User, on_delete=models.CASCADE)
    cena = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    lokalizacja = models.CharField(max_length=200, null=True, blank=True)
    zdjecie = models.ImageField(upload_to='ogloszenia/', null=True, blank=True)
    # Udogodnienia
    basen = models.BooleanField(default=False)
    wifi = models.BooleanField(default=False)
    klimatyzacja = models.BooleanField(default=False)
    parking = models.BooleanField(default=False)
    sauna = models.BooleanField(default=False)
    tv = models.BooleanField(default=False)
    grill = models.BooleanField(default=False)
    plac_zabaw = models.BooleanField(default=False)
    zwierzeta_dozwolone = models.BooleanField(default=False)

    def __str__(self):
        return self.tytul 