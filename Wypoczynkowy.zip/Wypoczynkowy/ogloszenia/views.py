from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import OgloszenieForm
from .models import Ogloszenie

@login_required
def dodaj_ogloszenie(request):
    if request.method == 'POST':
        form = OgloszenieForm(request.POST, request.FILES)
        if form.is_valid():
            ogloszenie = form.save(commit=False)
            ogloszenie.autor = request.user
            ogloszenie.save()
            return redirect('lista_ogloszen')
    else:
        form = OgloszenieForm()
    return render(request, 'ogloszenia/dodaj.html', {'form': form})

def szczegoly_ogloszenia(request, ogloszenie_id):
    ogloszenie = get_object_or_404(Ogloszenie, id=ogloszenie_id)
    return render(request, 'ogloszenia/szczegoly.html', {'ogloszenie': ogloszenie})

def lista_ogloszen(request):
    ogloszenia = Ogloszenie.objects.all().order_by('-data_dodania')
    return render(request, 'ogloszenia/lista.html', {'ogloszenia': ogloszenia})

@login_required
def edytuj_ogloszenie(request, ogloszenie_id):
    ogloszenie = get_object_or_404(Ogloszenie, id=ogloszenie_id)
    if request.method == 'POST':
        form = OgloszenieForm(request.POST, request.FILES, instance=ogloszenie)
        if form.is_valid():
            form.save()
            return redirect('lista_ogloszen')
    else:
        form = OgloszenieForm(instance=ogloszenie)
    return render(request, 'ogloszenia/edytuj.html', {'form': form})

@login_required
def usun_ogloszenie(request, ogloszenie_id):
    ogloszenie = get_object_or_404(Ogloszenie, id=ogloszenie_id)
    if request.method == 'POST':
        ogloszenie.delete()
        return redirect('lista_ogloszen')
    return render(request, 'ogloszenia/usun.html', {'ogloszenie': ogloszenie}) 