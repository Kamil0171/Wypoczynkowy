from django.contrib import admin
from .models import Ogloszenie

admin.site.register(Ogloszenie) 