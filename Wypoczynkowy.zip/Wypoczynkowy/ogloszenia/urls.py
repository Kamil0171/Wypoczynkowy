from django.urls import path
from . import views

urlpatterns = [
    path('dodaj/', views.dodaj_ogloszenie, name='dodaj_ogloszenie'),
    path('szczegoly/<int:ogloszenie_id>/', views.szczegoly_ogloszenia, name='szczegoly_ogloszenia'),
    path('lista/', views.lista_ogloszen, name='lista_ogloszen'),
    path('edytuj/<int:ogloszenie_id>/', views.edytuj_ogloszenie, name='edytuj_ogloszenie'),
    path('usun/<int:ogloszenie_id>/', views.usun_ogloszenie, name='usun_ogloszenie'),
] 