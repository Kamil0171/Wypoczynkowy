// static/js/contact.js

document.addEventListener('DOMContentLoaded', function() {
  const contactForm = document.getElementById('contactForm');
  const feedbackMessage = document.getElementById('feedbackMessage');

  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();

    const nameValue = document.getElementById('name').value.trim();
    const emailValue = document.getElementById('email').value.trim();
    const messageValue = document.getElementById('message').value.trim();

    if (!nameValue || !emailValue || !messageValue) {
      feedbackMessage.textContent = 'Proszę wypełnić wszystkie wymagane pola.';
      feedbackMessage.classList.remove('success');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailValue)) {
      feedbackMessage.textContent = 'Nieprawidłowy format adresu e-mail.';
      feedbackMessage.classList.remove('success');
      return;
    }

    fetch('https://twoje-api-endpoint.com/api/contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: nameValue,
        email: emailValue,
        message: messageValue
      })
    })
    .then(response => {
      if (response.ok) {
        return response.json();
      } else {
        throw new Error('Błąd w żądaniu do serwera');
      }
    })
    .then(data => {
      feedbackMessage.textContent = 'Wiadomość została pomyślnie wysłana!';
      feedbackMessage.classList.add('success');
      contactForm.reset();
    })
    .catch(error => {
      feedbackMessage.textContent = 'Błąd podczas przesyłania danych. Spróbuj ponownie.';
      feedbackMessage.classList.remove('success');
      console.error(error);
    });
  });
});